=============================
Ubercart Products Recommender
=============================

About this module
-----------------

This module provides two default views:

1. Users who ordered this product also ordered
2. Personal recommendation based on your previous purchase.

You can modify the default Views to meet your purpose.


Installation & Configuration
----------------------------

Please first follow README.txt file in Recommender API.

After install the module, please go to admin/config/recommender and compute the recommendations. Then you can enable the 2 default views, customize them if necessary, and then display the recommendations.

