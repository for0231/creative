README
------
README for the Image effect text test module.

This module contains 2 image styles to test text effects. It uses an image
containing a grid and a font which are included in the install package as well.

Hard Dependencies
-----------------
Hard dependencies:
- Imagecache actions.
- Image (Drupal core).
- Features
- System stream wrapper (http://drupal.org/project/system_stream_wrapper)

Soft Dependencies
-----------------
- Imagemagick (preferred toolkit, http://drupal.org/project/imagemagick).
