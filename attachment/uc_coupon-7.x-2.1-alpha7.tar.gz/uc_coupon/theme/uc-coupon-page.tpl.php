<!DOCTYPE html>
<html>
<head>
  <title>Coupon</title>
  <?php print $styles; ?>
</head>
<body onload="window.print();">
  <?php print $content ?>
</body>
</html>
